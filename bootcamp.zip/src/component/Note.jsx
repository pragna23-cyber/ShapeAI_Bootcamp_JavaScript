import React from "react";

function Note() {
  return (
    <div>
      <h1>Javascript and react.js</h1>
      <ul>
        <li>React is a JavaScript library for building user interfaces.</li>
        <li>React is used to build single page applications.</li>
        <li>React allows us to create reusable UI components.</li>
      </ul>
      <p>React is an open-source front-end JavaScript library for building user interfaces or UI components. It is maintained by Facebook and a community of individual developers and companies. React can be used as a base in the development of single-page or mobile applications</p>
    </div>
  );
}

export default Note;
